package com.company;

public class Angolo {

    private int gradi;
    private int primi;
    private int secondi;
    private int secondiottenuti;

    public Angolo(int gradi, int primi, int secondi) {  //COSTRUTTORE PARAMETRICO
        this.gradi = gradi;    //permette di richiamare una determinata istanza  di una classe
        this.primi = primi;
        this.secondi = secondi;
    }





    public String visualizzangolo()
    {
        return " GRADI:" + this.gradi + " | PRIMI:" + this.primi + " | SECONDI:"+ this.secondi;
    }






    public int aggiungiGradi(int n1) {
        System.out.println("aggiungi gradi è");
        gradi=gradi +n1;
        return gradi;
    }


    public void aggiungiPrimi(int n2) {
        System.out.println("aggiungi primi è");
        primi= primi + n2;
        while(primi>=60) {
            primi = primi -60;
            gradi++;
        }
        System.out.println(primi);
    }




    public void aggiungiSecondi(int n3) {
        System.out.println("aggiungi secondi è");
        secondi= secondi + n3;

        while(secondi>=60) {
            secondi = secondi -60;
            primi++;
        }
        System.out.println(secondi);
    }


    public int angoloSecondi() {
        System.out.println("somma espressa in secondi è");
        int secondiottenuti=gradi*3600 + primi*60 +secondi;
        return secondiottenuti;
    }

    public void secondiAngolo(int sec) {
        gradi = sec / 3600;
        sec = sec % 3600;
        primi = sec / 60;
        secondi = sec % 60;
    }



    public void differenzaSecondi(int sec) {
        System.out.println("la differenza è");
        int diff= angoloSecondi() - sec;
        secondiAngolo(diff);


    }


}


/*
package com.company;
public class Main {
    public static void main(String[] args) {

        Angolo a1=new Angolo(3, 4 , 57);







        System.out.println();

        System.out.println("l angolo ha queste caratteristiche :  "+a1.visualizzangolo());


        System.out.println();


        System.out.println(a1.aggiungiGradi(57));
        a1.aggiungiPrimi(60);

        System.out.println(a1.visualizzangolo());
        a1.aggiungiSecondi(5);


        System.out.println(a1.angoloSecondi());


        System.out.println(a1.visualizzangolo());

        a1.secondiAngolo(48);

        a1.differenzaSecondi(45);



        // System.out.println(a1.somma(79));


    }
}
 */
