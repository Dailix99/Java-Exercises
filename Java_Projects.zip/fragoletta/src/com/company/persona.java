package com.company;

public class persona {  //ricordare classe con la maiuscola iniziale

    private String cognome;
    private String nome;
    private String codice_fiscale;
    private String citta;

    public persona() {  //costruttore di default
        this.cognome=null;
        this.nome=null;
        this.codice_fiscale=null;
        this.citta=null;
    }

    public persona (String cogn, String n, String codf, String cit)
    {
        this.cognome = cogn;
        this.nome = n;
        this.codice_fiscale = codf;
        this.citta=cit;
    }

    public String getCognome ()
    {
        return cognome;
    }

    public String getNome ()
    {
        return nome;
    }

    public String getCodice_fiscale ()
    {
        return codice_fiscale;
    }

    public String getCitta ()
      {
        return citta;
    }


    public void setCognome (String cogn)
    {
        cognome = cogn;
    }
    public void setNome (String n)
    {
        nome = n;
    }
    public void setCodice_fiscale (String codf)
    {
        codice_fiscale = codf;
    }

    public void setCitta (String cit)
    {
         citta = cit;
    }

    public void annoNascitaPersona(String codf){
        String anno;
        anno=codf.substring(6,8);     //stampa l'intervallo compreso tra 6 e 8
        System.out.println("l'anno di nascita e' 20"+anno);
    }

   public String stampa_persona()
   {
       return "INFORMAZIONI PERSONA->  | COGNOME:" + cognome + " | NOME:" + nome + " | CODICE FISCALE:" + codice_fiscale + " | citta':" + citta;
    }

}

/*


package com.company;

import java.util.*;
import java.util.Scanner;
import java.util.Vector;


public class Main {
    public static void main(String[] args) {

        int scelta,cont=1;
        String cognome,nome,codfis,citta;
        int numeropresenze,numeroidentificativo;
        String codicedafiscalePerRicavareAnno;

        Scanner a = new Scanner(System.in);

        Vector<Stagista> v =new Vector<>();  //array dinamico

        persona p1=new persona(); //richiamo costruttore di default

        persona p2=new persona("donici","iustin","DNCSND04P09Z129N","chieti"); //costruttore parametrico
        System.out.println(p2.stampa_persona());
        codicedafiscalePerRicavareAnno=p2.getCodice_fiscale();  //salvo in una variabile string il codice fiscale della persona
        p2.annoNascitaPersona(codicedafiscalePerRicavareAnno); //richiamo il metodo che mi restuituisce l'anno di nascita passandoli il codice fiscale



        do {
            System.out.println("\ninserisci: \n1 per inserire uno stagista \n2 per visualizzare i dati degli stagistai \n3 per visualizzare l'anno di nascita di tutti gli stagisti \n0 per uscire");

            scelta = a.nextInt();
            a.nextLine();

            switch (scelta) {


                case 1:
                    System.out.println("\ninserisci il cognome del " + cont + " stagista ");
                    cognome = a.nextLine();
                    System.out.println("\ninserisci il nome del " + cont + " stagista ");
                    nome = a.nextLine();
                    System.out.println("\ninserisci il codice fiscale del " + cont + " stagista ");
                    codfis = a.nextLine();
                    System.out.println("\ninserisci la citta del " + cont + " stagista ");
                    citta = a.nextLine();

                    do{
                        System.out.println("\ninserisci il numero presenze del " + cont + " stagista ");
                    numeropresenze = a.nextInt();
                    if(numeropresenze <0)
                        System.out.println("\nil numero di ore deve essere maggiore di 0");
                     }while(numeropresenze <0);

                    System.out.println("\ninserisci il numero identificativo del "+cont+" stagista " );
                    numeroidentificativo=a.nextInt();
                    Stagista s =new Stagista(cognome,nome,codfis,citta,numeropresenze,numeroidentificativo); //creo oggetto di tipo sito
                    v.addElement(s);  //attribuzione dell'oggetto all'array dinamico (classe vector)

                    cont++;
                    break;

                case 2:
                    for(int i=0; i<v.size();i++) {
                        System.out.println(v.elementAt(i).stampa_stagista());   //elementAt(i) utilizzato per recuperare un elemento in un indice specifico del vettore
                    }
                    break;


                case 3:
                    int conta=1;
                    for (int  i = 0; i < v.size(); i++) {
                        codicedafiscalePerRicavareAnno=v.elementAt(i).getCodice_fiscale();
                        System.out.print(conta + " stagista:  ");
                        v.elementAt(i).annoNascitaPersona(codicedafiscalePerRicavareAnno);
                        conta++;
                    }
                    break;


            }  //chiudo switch

        } while (scelta != 0);


    }
}


 */
