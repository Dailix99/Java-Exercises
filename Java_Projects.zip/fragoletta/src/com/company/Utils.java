package com.company;


public class Utils {

    public Contenitore[] filtra (Contenitore[] c, Contenitore f) {

        int togli=0;  //contenitori da rimuovere
        for(int i=0;i < c.length; i++){
            if((c[i].getNomeLiquido()).equals(f.getNomeLiquido()))
            {
                c[i]=null;  //pongo a NUll il contenitore con stesso liquido del campione
                togli++;   //incremento del numero di contenitori da rimuovere
            }
        }
        int nuovadimensione=c.length-togli;
        Contenitore[] cf=new Contenitore[nuovadimensione];
        int s=0;    //indice o posizione del nuovo array filtrato
        for(int i=0;i < c.length; i++)
            if(c[i]!=null)  //tutti i contenitori che non sono NULL saranno copiati nel nuovo array di contenitori filtrati
            {
                cf[s]=c[i];
                s++;
            }
        return cf;   //sostituisco il vecchio array di oggetti con l'array di oggetti filtrato

    }
}
