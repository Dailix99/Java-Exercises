package com.company;

public interface CMP {
    void confronta(Contenitore c);
}
