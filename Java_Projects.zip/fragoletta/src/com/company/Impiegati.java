package com.company;

public class Impiegati extends Dipendent{

    public int bonus;


    public Impiegati(String n,String i,String cf,double bdr,int bn) {
        super(n,i,cf,bdr);
        this.bonus=bn;
    }



    public String toString() {
        return "Impiegati[" +
                "nome='" + nome + '\'' +
                ", indirizzo='" + indirizzo + '\'' +
                ", codice_fiscale='" + codice_fiscale + '\'' +
                ", basediretr=" + basediretr +
                ", bonus=" + bonus +
                ']';
    }

    public double paga() {
        return basediretr+bonus;
    }

}
