package com.company;

public class Borsellino {
    double totale=0;
    double tot=0;
    int indice=0;
    int dim=500;

    private double[] borsmon = new double[dim];



    public void addMonete(double valore, int quantita) {
        for(int i=indice;i<indice+quantita;i++) {
            borsmon[i]=valore;
        }
        indice+=quantita;
    }

    public boolean removeMoneta(double valore2) {

        for (int i = 0; i < indice; i++) {

            if (valore2 == borsmon[i]) {
                for(int j = i+1; j < indice; j++) {   //j<dim
                    borsmon[j-1] = borsmon[j];
                }
                indice--;
                return true;
            }
        }
        return false;
    }




    public void calcolatotale(){
        double s=0;
        for (int i=0;i<indice;i++)
        {
            s=s+borsmon[i];
        }
        System.out.println("il borsellino contiene:"+ s + " euro");
    }

    public void stamparray(){
        int cont=1;
        System.out.println("il borsellino contiene\n");
        for (int i=0;i<indice;i++)
        {
            System.out.print("la " + cont + " moneta e' "+ borsmon[i] +"\n");
            cont++;
        }
    }


    public void quantitatagliomoneta(double monetaquant){
        int conta=0;
        System.out.println("il numero di monete presenti con questo taglio sono");
        for (int i = 0; i < indice; i++) {

            if (monetaquant == borsmon[i]) {
                conta++;
            }
        }
        System.out.println(conta +"\n");
    }






         }





         /*



         package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner a = new Scanner(System.in);
        int scelta;
        double val;
        double val2;

                Borsellino b = new Borsellino();
                do {
                    System.out.println("inserisci \n 1 per aggiungere  Monete \n 2 per rimuovere le Monete\n 3 per calcolare il totale\n 4 per stampare tutte le monete \n 5 per restituire il numero di monete presenti dato un taglio \n 0 per uscire");

                    scelta = a.nextInt();
                    a.nextLine();

                    switch (scelta) {


                        case 1:
                            do {
                                System.out.println("inserisci la moneta che desideri:");
                                val = a.nextDouble();
                                if(val != 0.1 && val !=0.01 &&  val!=0.02 && val!=0.05 && val!=0.10 && val!=0.20 && val!=0.50 && val!=1 && val!=2 )
                                {
                                    System.out.println("moneta non esistente,reinserire:\n");
                                }
                            }while(val != 0.1 && val !=0.01 &&  val!=0.02 && val!=0.05 && val!=0.10 && val!=0.20 && val!=0.50 && val!=1 && val!=2 );
                            a.nextLine();
                            System.out.println("inserisci la quantita' della moneta che hai inserito:");
                            int quant=a.nextInt();
                            b.addMonete(val, quant);
                            break;

                        case 2:
                                System.out.println("inserisci la moneta che desideri ritirare dal borsellino:");
                                val2 = a.nextDouble();
                                System.out.println(b.removeMoneta(val2));
                            break;

                        case 3:
                            b.calcolatotale();
                        break;

                        case 4:
                            b.stamparray();
                            break;
                        case 5:
                            System.out.println("inserisci la moneta di cui desideri vedere la quantita':");
                            double mq=a.nextDouble();
                            b.quantitatagliomoneta(mq);
                            break;
                    }

                } while (scelta != 0);
            }

        }








          */


