package com.company;

public class Punto {
    int x,y;


    public Punto(int x,int y) {
        this.x=x;
        this.y=y;
    }

    public String toString(){
        return "x=" + x + ", y=" + y ;
    }

}














/*
package com.company;
import java.util.Scanner;
import java.util.Vector;

public class Main {

    public static void main(String[] args) {
        int scelta,pos,x,y,sostx,sosty;

        Scanner a = new Scanner(System.in);
        Vector<Punto>v=new Vector<>();

        Poligono pl=new Poligono();
 /*
        Punto p1=new Punto(3,4);
        Punto p2=new Punto(5,6);
        Punto p3=new Punto(-2,2);

        v.addElement(p1);
        v.addElement(p2);
        v.addElement(p3);
*/

/*
        do {
                System.out.println("inserisci \n1 per aggiungere un punto \n2 per rimuovere un punto\n3 per modificare\n4 per stampare \n0 per uscire");

                scelta = a.nextInt();
                a.nextLine();

                switch (scelta) {


                case 1:
                System.out.println("inserisci la coordinata x del punto");
                x = a.nextInt();
                System.out.println("inserisci la coordinata y del punto");
                y = a.nextInt();
                Punto p=new Punto(x,y);
                pl.aggiungi(p);
                break;

                case 2:
                System.out.println("inserisci la posizione del punto che vuoi rimuovere");
                pos = a.nextInt();
                pl.rimuovi(pos);
                break;

                case 3:
                System.out.println("inserisci la posizione del punto che vuoi modificare");
                pos = a.nextInt();
                System.out.println("inserisci la nuova coordinata x del punto che vuoi modificare ");
                sostx = a.nextInt();
                System.out.println("inserisci la nuova coordinata y del punto che vuoi modificare ");
                sosty = a.nextInt();
                pl.modifica(pos,sostx,sosty);
                break;

                case 4:
                pl.stampa();
                break;

                }

                } while (scelta != 0);


                }
                }
 */