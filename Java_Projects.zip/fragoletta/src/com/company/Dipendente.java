package com.company;

    public class Dipendente {
        String nome;
        double stipendio;


        public Dipendente() {
            this.nome="fabio";
            this.stipendio=1000;
        }

        public Dipendente(Dipendente p) {
            this.nome=p.nome;
            this.stipendio=p.stipendio;
        }

        public Dipendente(String n,double s) {
            this.nome=n;
            this.stipendio=s;
        }

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public double getStipendio() {
            return stipendio;
        }

        public void setStipendio(double stipendio) {
            this.stipendio = stipendio;
        }


        public void aumento(double percentuale) {
            double risultato=(this.stipendio*percentuale)/100;
            this.stipendio=stipendio+risultato;

        }


         public void unatantum(double quantita) {
             if (stipendio < 1200) {
                 System.out.println("\n non e' possibile ridurre lo stipendio dato che risulta minore di 1200$\n");
             }
             else{
                 this.stipendio = this.stipendio - quantita;
                 System.out.println("\n riduzione dello stipendio completata\n");
             }
         }



            public boolean equal(Dipendente d){

                 if (this.stipendio == d.getStipendio()) {
                     return true;
                 }
                 return false;
             }

                  public String toString(){
                    return " dipendente [nome=" + nome + ", stipendio=" + stipendio + "]";
                    }

                    public void stampadati() {
                    System.out.println("dipendente [nome=" + nome + ", stipendio=" + stipendio + "]");
             }


         }




     /*


    package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        String nom,nomedacercar,con1,con2;
        double stipend,percen,quant,salva=0;
        int cont=1,cont2,n,scelta,indice=0,i,y,j=0;



        Scanner a = new Scanner(System.in);
        do {
            System.out.println("quanti dipendenti vuoi inserire?");
            n = a.nextInt();
        }while(n>20 || n<=0);


        Dipendente d[] = new Dipendente[n];

        do {
            System.out.println("inserisci \n 1 inserire i dati dei dipendenti   \n 2 per fare un aumento di stipendio al dipendente \n 3  per togliere una quantita di denaro dallo stipendio del dipendente\n 4  per stampare i dati del dipendente\n 5 per confrontare lo stipendio di 2 dipendenti (true:uguali / false:diversi)\n 0 per uscire");
            scelta=a.nextInt();
            switch (scelta) {


                case 1:

                    if (indice==n) {
                        System.out.println("\nnumero di dipendenti massimi da poter inserire superato\n");
                    }

                    else{
                        for ( i = 0; i <n; i++) {
                            a.nextLine();
                            System.out.println("\ninserisci il nome del "+cont+" dipendente " );
                            nom=a.nextLine();
                            System.out.println("\ninserisci lo stipendio del "+cont+" dipendente " );
                            stipend=a.nextDouble();
                            cont++;
                            d[i] = new Dipendente(nom, stipend);  //costruttore parametrico
                        }
                        indice+=n;
                    }
                    a.nextLine();




                //    Dipendente d1=new Dipendente("giovanni", 23); //costruttore parametrico
                //    Dipendente d2=new Dipendente(d1);  //costuttore di copia
                //    Dipendente d3=new Dipendente();    //costruttore di default




                    break;

                case 2:
                    a.nextLine();
                    System.out.println("\ninserisci il nome del dipendente a cui vuoi fare l'aumento");
                    nomedacercar=a.nextLine();

                    for ( i = 0; i < n; i++) {

                    if (d[i].getNome().equals(nomedacercar)) {
                        System.out.println("\ninserisci la percentuale di stipendio da aumentare\n");
                        percen=a.nextDouble();
                        d[i].aumento(percen);
                    }
                }





                    break;

                case 3:
                    a.nextLine();
                    System.out.println("\ninserisci il nome del dipendente a cui vuoi fare la riduzione dello stipendio\n");
                    nomedacercar=a.nextLine();

                    for ( i = 0; i < n; i++) {

                        if (d[i].getNome().equals(nomedacercar)) {
                            System.out.println("\ninserisci la quantita' di denaro da togliere al dipendente");
                            quant=a.nextDouble();
                            d[i].unatantum(quant);
                        }
                    }


                    break;


                case 4:
                    System.out.println("\n");
                    cont2=1;
                    for ( i = 0; i < n; i++) {
                        System.out.println(cont2+d[i].toString());
                        cont2++;
                    }
                    System.out.println("\n");


                //    for (int i = 0; i < n; i++) {
                //        d[i].stampadati();  //stampo con il metoodo void }

                    break;

                case 5:
                    a.nextLine();
                    System.out.println("\ninserisci il nome del 1 dipendente a cui vuoi confrontare lo stipendio\n");
                    con1=a.nextLine();

                    for ( i = 0;  i< n; i++) {

                        if (d[i].getNome().equals(con1)) {
                            j=i; //salvo posizione
                            System.out.println("\n 1 dipendente trovato\n");
                        }
                    }

                    System.out.println("\ninserisci il nome del 2 dipendente a cui vuoi confrontare lo stipendio\n");
                    con2=a.nextLine();

                    for (y = 0; y < n; y++) {

                        if (d[y].getNome().equals(con2)) {
                            System.out.println("\n 2 dipendente trovato\n");
                            System.out.println(d[j].equal(d[y])); //richiamo il metodo equal
                        }
                    }


                    break;


            }

        } while (scelta != 0) ;

    }
}


     */