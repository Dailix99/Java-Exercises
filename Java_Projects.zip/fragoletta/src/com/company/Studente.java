package com.company;

public class Studente {

    private String cognome;
    private String nome;
    private double voto;


    public Studente(String n, String f, double u) {
        cognome = n;
        nome = f;
        voto = u;

    }

    public String getCognome() {
        return cognome;
    }

    public String getNome() {
        return nome;
    }

    public Double getVoto() {
        return voto;
    }



    public String datistudente() {
        return "COGNOME:" + cognome + " | NOME:" + nome + " | VOTO:" + voto;
    }



    }



    /*

    package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int scelta;
        int n=1;
        int indice=0;
        int num = 1;
        int va=0;
        int p=0 ,p1=0;
        double x;
        double vot;
        double somma=0 , media=0;


        Scanner a = new Scanner(System.in);


        System.out.println("inserisci il numero di studenti massimi che desideri implementare nel sistema:");
        n = a.nextInt();
        a.nextLine();
        Studente s[] = new Studente[n];

        do {
            System.out.println("inserisci \n 1 per inserire gli studenti \n 2 per stampare gli studenti\n 3 per stampare lo studente migliore/peggiore\n 4 per stampare la media voti\n 5 per stampare i dati degli studenti che devono recuperare\n 0 per uscire");

            scelta = a.nextInt();


            switch (scelta) {


                case 1:
                    if (indice >= n) {
                        System.out.println("\ni dati di tutti gli studenti sono gia' stati inseriti\n");
                    }
                    else{
                    for (int i = indice; i < indice+n; i++) {
                                a.nextLine();
                                System.out.println("inserisci il cognome del " + num + " studente:");
                                String cognom = a.nextLine();
                                System.out.println("inserisci il nome del " + num + " studente:");
                                String nom = a.nextLine();
                                do {
                                    System.out.println("inserisci il voto del " + num + " studente:");
                                    vot = a.nextDouble();
                                    if(vot<0 || vot>10 ){
                                        System.out.println("voto non valido,reinserire");
                                    }
                                }while(vot<0 || vot>10);
                                System.out.println("  ");
                                num++;
                                s[i] = new Studente(cognom, nom, vot);
                                va++;
                            }
                        }
                        indice+=n;
                        a.nextLine();
                        break;

                        case 2:
                            int f = 1;
                            System.out.println("\n");
                            if(va==0)
                            {
                                System.out.println("\nnon e' stato inserito nessuno studente\n");
                            }
                            else {
                                for (int i = 0; i < n; i++) {
                                    System.out.println("il " + f + " studente ha " + s[i].datistudente());
                                    f++;
                                }
                                System.out.println("\n");
                            }
                            break;

                        case 3:
                            x=s[0].getVoto();
                            System.out.println("\n");
                            for (int i = 0; i < n; i++) {
                                if( s[i].getVoto()>x ) {
                                    x=s[i].getVoto();
                                     p=i;
                                }
                            }
                            System.out.println("il voto migliore e'quello dello studente "+s[p].datistudente());
                            System.out.print("\n");

                            x=s[0].getVoto();
                            for (int i = 0; i < n; i++) {
                                if( s[i].getVoto()<x ) {
                                    x=s[i].getVoto();
                                    p1=i;
                                }
                            }
                            System.out.println("il voto peggiore e'quello dello studente "+s[p1].datistudente());
                            System.out.print("\n");


                            break;

                        case 4:
                            for (int i = 0; i < n; i++) {
                                    somma=somma+s[i].getVoto();
                                }
                            media=somma/n;
                            System.out.println("\nla media dei voti di tutti gli studenti e' "+media);
                            System.out.print("\n");
                            break;
                        case 5:
                            for (int i = 0; i < n; i++) {
                                if( s[i].getVoto()<6 ) {
                                    System.out.println("\nLo studente "+s[i].datistudente()+ " deve recuperare\n");
                                }
                            }

                            break;
                    }

            } while (scelta != 0) ;

    }
}


     */







