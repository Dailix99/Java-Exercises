package com.company;

public class Bidoni extends Contenitore {

    public Bidoni(String c,String n, double q) {
        super(c,n,q);
    }


    public String toString() {
        return "Bidoni{" +
                "codice='" + codice + '\'' +
                ", nome='" + nomeliquido + '\'' +
                ", quantita=" + quantita +
                '}';
    }
}
