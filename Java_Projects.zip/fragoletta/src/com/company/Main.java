package com.company;

import java.util.Scanner;
import java.util.InputMismatchException;
import java.lang.ArrayIndexOutOfBoundsException;

public class Main {

        public static void main(String[] args) {


                int scelta,scelta2,n=10,bonus,cont_oggetti=0;
                int contv=1,contd=1,contg=1,conti=1;
                double basedir,paga_fissa=0,giornatelavor;
                String nome,indirizzo,codfis;
                boolean errore=true;

                Scanner in = new Scanner(System.in);

                System.out.println("\ninserisci il numero di personale massimo desiderato: ");

                do {
                        try {
                                n = in.nextInt();  //se non si inserisce un int si attiva/richiama l'eccezzione e di conseguenza il relativo errore
                                errore=false;  //se  l'input e' un dato int la variabile errore diventa false e si esce subito dal do while
                        } catch (InputMismatchException e) {
                                System.out.println("\n ERRORE:inserire un intero e non una stringa");
                                in.next();  //passa all'altra eventuale eccezione successiva
                        }
                }while(errore==true); //se errore e' true si ripete ii ciclo

                Personale p[]=new Personale[n];


                in.nextLine();

                do {
                        System.out.println("\ninserisci: \n 1 per inserire un volontario \n 2 per inserire un dipendente/giornalista/impiegato \n 3 per stampare i dati del personale \n 4 per calcolare la paga del personale \n 0 per uscire");

                        scelta = in.nextInt();
                        in.nextLine();

                        switch (scelta) {


                                case 1:

                                        System.out.println("\ninserisci il nome del " + contv + " volontario ");
                                        nome = in.nextLine();
                                        System.out.println("\ninserisci l'indirizzo del " + contv + " volontario ");
                                        indirizzo = in.nextLine();
                                        System.out.println("\ninserisci il codice fiscale del " + contv + " volontario ");
                                        codfis = in.nextLine();


                                        try {
                                                p[cont_oggetti] =new Volontario(nome,indirizzo,codfis,paga_fissa); //creo oggetto volontario di tipo personale
                                                cont_oggetti++;

                                        }
                                        catch (ArrayIndexOutOfBoundsException e){
                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                        }


                                        contv++;

                                        break;





                                case 2:


                                        System.out.println("\ninserire... \n 1 per aggiungere un dipendente \n 2 per aggiungere un giornalista \n 3 per aggiungere un impiegato");
                                        scelta2 = in.nextInt();

                                        in.nextLine();


                                        switch (scelta2) {

                                                case 1:

                                                        System.out.println("\ninserisci il nome del " + contd + " dipendente ");
                                                        nome = in.nextLine();
                                                        System.out.println("\ninserisci l'indirizzo del " + contd + " dipendente ");
                                                        indirizzo = in.nextLine();
                                                        System.out.println("\ninserisci il codice fiscale del " + contd + " volontario ");
                                                        codfis = in.nextLine();
                                                        System.out.println("\ninserisci la base di retribuzione del  " + contd + " volontario ");
                                                        basedir = in.nextDouble();

                                                        try {
                                                                p[cont_oggetti] =new Dipendent(nome,indirizzo,codfis,basedir);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }

                                                        contd++;

                                                        break;



                                                case 2:

                                                        System.out.println("\ninserisci il nome del " + contg + " giornalista ");
                                                        nome = in.nextLine();
                                                        System.out.println("\ninserisci l'indirizzo del " + contg + " giornalista ");
                                                        indirizzo = in.nextLine();
                                                        System.out.println("\ninserisci il codice fiscale del " + contg + " giornalista ");
                                                        codfis = in.nextLine();
                                                        System.out.println("\ninserisci la base di retribuzione del  " + contg + " giornalista ");
                                                        basedir = in.nextDouble();
                                                        System.out.println("\ninserisci il numero di giornate lavorative del " + contg + " giornalista ");
                                                        giornatelavor = in.nextDouble();

                                                        try {
                                                                p[cont_oggetti] =new Giornalieri(nome,indirizzo,codfis,basedir,giornatelavor);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }

                                                        contg++;

                                                        break;


                                                case 3:

                                                        System.out.println("\ninserisci il nome del " + conti + " impiegato ");
                                                        nome = in.nextLine();
                                                        System.out.println("\ninserisci l'indirizzo del " + conti + " impiegato ");
                                                        indirizzo = in.nextLine();
                                                        System.out.println("\ninserisci il codice fiscale del " + conti + " impiegato ");
                                                        codfis = in.nextLine();
                                                        System.out.println("\ninserisci la base di retribuzione del " + conti + " impiegato ");
                                                        basedir = in.nextDouble();
                                                        System.out.println("\ninserisci il bonus del " + conti + " impiegato ");
                                                        bonus = in.nextInt();

                                                        try {
                                                                p[cont_oggetti] =new Impiegati(nome,indirizzo,codfis,basedir,bonus);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }

                                                        conti++;

                                                        break;


                                        }//chiusura  del menu interno del 2 case del menu principale

                                        break;  //chiusura  del 2 case del menu principale


                                case 3:
                                        int conta1=1;

                                        for(int i=0; i<cont_oggetti; i++) {
                                                System.out.println(conta1+" membro del personale,ovvero--> "+p[i].toString());
                                                conta1++;
                                        }

                                        break;



                                case 4:
                                        int conta2=1;

                                        for(int i=0; i<cont_oggetti; i++) {
                                                //System.out.println("paga del "+ conta2 +" membro del personale--> "+p[i].paga());
                                                p[3].paga();
                                                conta2++;
                                        }


                                        break;


                        }  //chiudo switch

                } while (scelta != 0);


        }
}