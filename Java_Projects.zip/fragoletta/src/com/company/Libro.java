package com.company;

public class Libro {

    private String titolo;
    private String autore;
    private int numeroPagine;
    private static double costoPagina = 0.05;  //variabile statica è unica per tutte le istanze (oggetti) della classe, se un oggetto la modifica, la modifica vale per tutti gli oggetti.
    final double COSTO_FISSO = 5.5;  //variabile dichiarata final assume valore di costante

    public Libro(String titolo, String autore, int numeroPagine) {
        this.titolo = titolo;
        this.autore = autore;
        this.numeroPagine = numeroPagine;
    }

    public  Libro(Libro l) {
        this.titolo = l.titolo;
        this.autore = l.autore;
        this.numeroPagine = l.numeroPagine;
    }
    public String getTitolo() {
        return titolo;
    }

    public String getAutore() {
        return autore;
    }

    public int getNumeroPagine() {
        return numeroPagine;
    }

    public static double getCostoPagina() {
        return costoPagina;
    }

    public void setTitolo(String m) {
        titolo = m;
    }

    public void setAutore(String n) {
        autore = n;
    }

    public void setNumero_brani(int c) {
        numeroPagine = c;
    }

    public static void setCostoPagina(double costo){   //modifica l'attributo statico condiviso da tutti gli oggetti della classe
        costoPagina=costo;
    }

  public double prezzo() {
      return COSTO_FISSO + numeroPagine * costoPagina;
  }






}



/*
package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Libro l1=new Libro(" leone asmatico", "fernando", 150);
        Libro l2=new Libro(" il ggg", "filippo", 80);

        Libro l3=new Libro(l1);

        l1.setCostoPagina(0.1);

        System.out.println(l1.getTitolo()+" : " + l1.prezzo());
        System.out.println(l2.getTitolo()+" : " + l2.prezzo());
        System.out.println(l3.getTitolo()+" costruttore di copia: " + l3.prezzo());

    }
}
 */











