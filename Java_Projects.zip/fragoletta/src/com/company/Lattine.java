package com.company;

public class Lattine extends Contenitore  {

    public Lattine(String c,String n, double q) {
        super(c,n,q);
    }


    public String toString() {
        return "Lattine{" +
                "codice='" + codice + '\'' +
                ", nome='" + nomeliquido + '\'' +
                ", quantita=" + quantita +
                '}';


    }
}
