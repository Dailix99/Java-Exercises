package com.company;

public class Giornalieri extends Dipendent {
    public double giornate_lavorative;


    public Giornalieri(String n,String i,String cf,double bdr,double gl) {
        super(n,i,cf,bdr);
        this.giornate_lavorative=gl;
    }


    public String toString() {
        return "Giornalieri[" +
                "nome='" + nome + '\'' +
                ", indirizzo='" + indirizzo + '\'' +
                ", codice_fiscale='" + codice_fiscale + '\'' +
                ", basediretr=" + basediretr +
                ", giornate_lavorative=" + giornate_lavorative +
                ']';
    }

    public double paga() {
        return basediretr*giornate_lavorative;
    }
}
