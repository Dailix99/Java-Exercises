package com.company;

public class cilindro extends cerchio{
double altezza;

    public cilindro(double r,double a) {
        super(r);
        this.altezza=a;
    }

    public void calcolaVolume() {
        double volume= (Math.PI * raggio * raggio ) *altezza;
        System.out.println("il volume del cilindro e': "+volume);
    }

    public void calcolaSuperficieTotale() {
        double superficietot=(2 * Math.PI * raggio*altezza)+(2 * Math.PI * raggio*raggio);
        System.out.println("la superficie totale del cilindro e': "+superficietot);
    }

}
