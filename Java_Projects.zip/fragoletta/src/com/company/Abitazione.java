package com.company;

public class Abitazione {

    int numero_stanze;
    double superficie;
    String indirizzo;
    String citta;

    public Abitazione(int ns,double s, String i, String c) {
        this.numero_stanze=ns;
        this.superficie=s;
        this.indirizzo=i;
        this.citta=c;
    }

    public String stampa_abitazione(){
        return "numero_stanze=" + numero_stanze + ", superficie=" + superficie + ", indirizzo=" + indirizzo +  ", città=" + citta ;
    }



}







/*
package com.company;
import java.util.Scanner;
import java.lang.Math;

public class Main {

    public static void main(String[] args) {
        String rag;
        String pis;
        Scanner in = new Scanner(System.in);

        Abitazione a = new Abitazione(3,54.90,"via verdi","gallipoli");
        System.out.println("l'abitazione ha: "+a.stampa_abitazione());

        System.out.println("\nl'appartemento e' raggiungibile tramite ascensore oppure no? inserisci 'si' se è raggiungibile altrimenti inserisci 'no'");
        rag=in.nextLine();
        boolean raggiungibile=rag.equals("si")?true:false;
        Appartamento p=new Appartamento(5,56.80,"via francesco totti","Roma",5,2,raggiungibile);
        //System.out.println(p.raggiungibile(rag));
        System.out.println(p.stampa_appartamento());



        System.out.println("\nla villa ha la piscina oppure no? inserisci 'si' se ha la piscina altrimenti inserisci 'no'");
        pis=in.nextLine();
        boolean piscina=pis.equals("si")?true:false;
        Villa v=new Villa(8,85.20,"via calliope","bari",1,670.45,piscina);
        //System.out.println(v.piscina(pis));
        System.out.println(v.stampa_villa());

    }
}
 */