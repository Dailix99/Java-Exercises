package com.company;
public class Conto {

    private double saldo;
    private double idconto;
    private String titolare;
    public double password;

    public Conto(double t , String ti, double p) {  //COSTRUTTORE PARAMETRICO
        this.idconto=t;
        this.titolare=ti;
        this.password=p;
        this.saldo = 0 ;
    }



    public String visualizzaConto()
    {
        return " saldo: " + this.saldo+ " | idconto: " + this.idconto + " titolare:"+ this.titolare ;
    }





    public void versa(double unaQuantita)
    {
        saldo = saldo + unaQuantita;
    }




    public void prelievo(double quantitadaprelevare)
    {
        if(quantitadaprelevare==saldo) {

            System.out.println("sara' ritirato l'intero saldo attuale");
            saldo=saldo-quantitadaprelevare;

        }
        else if(quantitadaprelevare<saldo)
        {
            System.out.println("importo da ritirare desiderato in estrazione..");
            saldo=saldo-quantitadaprelevare;
        }
        else if(quantitadaprelevare>saldo){
            System.out.println("non è possibile ritirare l importo desiderato dato che il saldo non è sufficiente");
        }
    }

}




/*

package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int c;
        int u;
        u=3;
        String scelta="y";


        Scanner a = new Scanner(System.in);
        System.out.println("inserisci l'id :");
        double id = a.nextDouble();
        a.nextLine();
        System.out.println("inserisci il cognome del titolare:");
        String tit = a.nextLine();
        double pass=23;



        Conto c1 = new Conto(id, tit , pass);
        do{

            System.out.println("inserisci la password per entrare nel conto: ");
            double password = a.nextDouble();
            a.nextLine();


            if(password==pass){
                do {


                    System.out.println("selezionare la  modalita' desiderata: \n1 per stampare i dati del conto , \n2 per versare sul conto , \n3 per prelevare");
                    do {

                        c = a.nextInt();
                        a.nextLine();
                        if (c < 0 || c > 3) {
                            System.out.println("    reinserisci  ");
                        }
                    } while (c < 0 || c > 3);

                    System.out.println();



                    switch (c) {

                        case 1:
                            System.out.println("il distributore ha queste caratteristiche :  \n" + c1.visualizzaConto());
                            break;

                        case 2:
                            System.out.println("versa :");
                            c1.versa(a.nextDouble());
                            a.nextLine();
                            break;


                        case 3:
                            System.out.println("prelieva");
                            c1.prelievo(a.nextDouble());
                            a.nextLine();
                            break;

                    }
                    System.out.println();
                    System.out.println("inserisci 'y' se vuoi fare altre operazioni oppure 'n' se vuoi terminare");
                    scelta=a.nextLine();
                } while (scelta.equals("y"));



            }

            else{
                System.out.println("riprova: ");
                u--;
                System.out.println(u + " tentativi rimasti");
                if(u==0)
                {
                    System.out.println("conto bloccato! complimenti");
                }
            }


        }while(u!=0 && scelta.equals("y") );



    }
}

 */
