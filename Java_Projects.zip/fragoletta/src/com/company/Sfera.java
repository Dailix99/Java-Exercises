package com.company;
import java.lang.Math;

public class Sfera extends Solido {

    public double raggio;

    public Sfera(double ps,double v,double r){
        super(ps,v);
        raggio=r;
    }


    public  String getDescrizione(){   //definisco concretamente il metodo (nella classe Solido e' astratto)
        return "la sfera ha come raggio ["+raggio+ "] peso specifico ["+pesospecifico+"] volume ["+volume+"]";
    }


    public double superficie(){    //definisco concretamente il metodo (nella classe Solido e' astratto)
        return 4*Math.PI*raggio*raggio;
    }

    public double volume(){      //definisco concretamente il metodo (nella classe Solido e' astratto)
        return 4/3 *Math.PI*raggio*raggio*raggio;
    }


}
