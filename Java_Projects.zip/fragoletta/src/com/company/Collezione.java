package com.company;

public class Collezione {

    private String nome;
    private String luogo;
    private OperaArte od[];

    public Collezione(String n,String l,int dim){
        nome=n;
        luogo=l;
        od=new OperaArte[dim];
    }


}



/*
package com.company;

import java.util.*;

public class Main {

        public static void main(String[] args) {

                int scelta,scelta2,cont_oggetti=0,j=0,contq=1,conts=1,dim,i,y;
                double altezza,lunghezza,larghezza,profondita;
                String titolo,artista,nomecol,luogo;


                Scanner in = new Scanner(System.in);



                System.out.println("\ninserisci il nome della collezione");
                nomecol = in.nextLine();
                System.out.println("\ninserisci il luogo della collezione");
                luogo = in.nextLine();
                System.out.println("\ninserisci il numero di opere d'arte massimo desiderato: ");
                dim=in.nextInt();
                Collezione c=new Collezione(nomecol,luogo,dim);

                OperaArte od[]=new OperaArte[dim];  //array di oggetti di tipo opera d'arte


                in.nextLine();

                do {
                        System.out.println("\ninserisci: \n 1 per aggiungere una nuova opera d'arte \n 2 per stampare le caratteristiche delle opere d'arte \n 3 per calcolare l'ingombro \n 4 per confrontare 2 opere d'arte  \n 0 per uscire");

                        scelta = in.nextInt();
                        in.nextLine();

                        switch (scelta) {



                                case 1:


                                        System.out.println("\ninserire... \n 1 per aggiungere un quadro \n 2 per aggiungere una scultura");
                                        scelta2 = in.nextInt();

                                        in.nextLine();


                                        switch (scelta2) {

                                                case 1:

                                                        System.out.println("\ninserisci il titolo del " + contq + " quadro ");
                                                        titolo = in.nextLine();
                                                        System.out.println("\ninserisci l'artista del " + contq + " quadro ");
                                                        artista = in.nextLine();
                                                        System.out.println("\ninserisci l'altezza del " + contq + " quadro ");
                                                        altezza = in.nextDouble();
                                                        System.out.println("\ninserisci la lunghezza del  " + contq + " quadro ");
                                                        lunghezza = in.nextDouble();

                                                        try {
                                                                od[cont_oggetti] =new Quadro(titolo,artista,altezza,lunghezza);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }

                                                        contq++;

                                                        break;



                                                case 2:

                                                        System.out.println("\ninserisci il titolo della " + conts + " scultura ");
                                                        titolo = in.nextLine();
                                                        System.out.println("\ninserisci l'artista della " + conts + " scultura ");
                                                        artista = in.nextLine();
                                                        System.out.println("\ninserisci l'altezza della " + conts + " scultura ");
                                                        altezza = in.nextDouble();
                                                        System.out.println("\ninserisci la larghezza della  " + conts + " scultura ");
                                                        larghezza = in.nextDouble();
                                                        System.out.println("\ninserisci la profondita della  " + conts + " scultura ");
                                                        profondita = in.nextDouble();

                                                        try {
                                                                od[cont_oggetti] =new Scultura(titolo,artista,altezza,larghezza,profondita);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }

                                                        conts++;

                                                        break;



                                        }//chiusura  del menu interno del 1 case del menu principale
                                        break;  //chiusura  del 1 case del menu principale


                                case 2:
                                        int conta1=1;

                                        for(i=0; i<cont_oggetti; i++) {
                                                System.out.println(conta1+" opera d'arte,ovvero--> "+od[i].toString());
                                                conta1++;
                                        }

                                        break;



                                case 3:
                                        int conta2=1;

                                        for(i=0; i<cont_oggetti; i++) {
                                                System.out.println("ingombro della "+ conta2 +" opera d'arte-> "+od[i].printingombro());
                                                conta2++;
                                        }


                                        break;

                                case 4:

                                        System.out.println("\ninserisci la posizione della 1 operare d'arte  che vuoi confrontare (si parte dalla posizione 0) \n");
                                        j=in.nextInt();
                                        System.out.println("\ninserisci la posizione della 2 operare d'arte  che vuoi confrontare \n");
                                        y=in.nextInt();

                                        System.out.println(od[j].equal(od[y])); //richiamo il metodo equal

                                        break;


                        }  //chiudo switch principale

                } while (scelta != 0);  //ripeto fino a quando scelta e' diverso da 0


        }
}
 */