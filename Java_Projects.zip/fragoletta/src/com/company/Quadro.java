package com.company;

public class Quadro extends OperaArte {

    private double altezza;
    private double lunghezza;

    public Quadro(String t,String a,double al,double l){
        super(t,a);
        altezza=al;
        lunghezza=l;
    }


    public double printingombro(){
        return altezza*lunghezza;
    }


    public String toString() {
        return "Quadro {" +
                "titolo='" + titolo + '\'' +
                ", artista='" + artista + '\'' +
                ", altezza=" + altezza +
                ", lunghezza=" + lunghezza +
                '}';
    }
}
