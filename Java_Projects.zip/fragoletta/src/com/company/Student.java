package com.company;



    public class Student {
        String name;
        String surname;
        double vote;

        static int counter = 0;

        public Student(String name, String surname, double vote) {
            this.name = name;
            this.surname = surname;
            this.vote = vote;

            counter++;
        }

        public void printStudents(int j) {
            System.out.println("\n               Studente " + (j + 1));
            System.out.println(" Nome: " + name);
            System.out.println(" Cognome: " + surname);
            System.out.println(" Voto: " + vote);
        }
    }



    /*

    package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // NON FUNZIONANTE IL METODO cls SU GDB ONLINE NELLA CLASSE Menu----------------------------------------------------------------
        Student[] students = new Student[999];
        Scanner scanner = new Scanner(System.in);
        short betterPosition = 0, worsePosition = 0;
        double betterVote = -1, worseVote = 11, tot = 0;
        byte mode;
        String cont;
        boolean exit = false, verify = false;

        Menu.mainMenu();

        do {
            do {
                mode = Menu.generalMenu();

                if(mode < 0 || mode > 2) {
                    Menu.menuError();
                    Menu.cls();
                }
            } while(mode < 0 || mode > 2);

            switch(mode) {
                case 1:
                    byte vote;

                    Menu.cls();
                    Menu.title();
                    System.out.print("\n -------------------------------------------------\n");
                    System.out.print(" |                 CREAZIONE STUDENTE            |\n");
                    System.out.print(" -------------------------------------------------\n");

                    System.out.print("\n Nome: ");
                    String name = scanner.nextLine();

                    System.out.print(" Cognome: ");
                    String surname = scanner.nextLine();

                    do {
                        System.out.print(" Voto: ");
                        vote = scanner.nextByte();
                        scanner.nextLine();

                        if(vote < 0 || vote > 10) {
                            System.out.print("\n --------------------------------------\n");
                            System.out.print(" |                ERRORE                |\n");
                            System.out.print(" |--------------------------------------|\n");
                            System.out.print(" |                                      |\n");
                            System.out.print(" | il voto non e' compreso tra 0 e 10   |\n");
                            System.out.print(" | Premi invio per continuare...        |\n");
                            System.out.print(" ----------------------------------------\n\n");

                            cont = scanner.nextLine();
                        }
                    } while(vote < 0 || vote > 10);

                    students[students[0].counter] = new Student(name, surname, vote);
                    break;

                // ----------------------------------------------------------------------------
                case 2:
                    do {
                        do {
                            do {
                                mode = Menu.functionsMenu();
                                verify = false;

                                if((mode == 2 && students[0].counter < 2) || (mode == 3 && students[0].counter < 2)) {
                                    System.out.print("\n ----------------------------------------------------\n");
                                    System.out.print(" |                      ERRORE                      |\n");
                                    System.out.print(" |--------------------------------------------------|\n");
                                    System.out.print(" |                                                  |\n");
                                    System.out.print(" | Troppi pochi studenti per questo comando (MIN 2) |\n");
                                    System.out.print(" | Premi invio per continuare...                    |\n");
                                    System.out.print(" ----------------------------------------------------\n\n");

                                    cont = scanner.nextLine();
                                }
                            } while((mode == 2 && students[0].counter < 2) || (mode == 3 && students[0].counter < 2));

                            if(mode < 0 || mode > 4) {
                                Menu.menuError();
                                Menu.cls();
                            }
                        } while(mode < 0 || mode > 4);

                        switch(mode) {
                            case 1:
                                Menu.cls();
                                Menu.title();

                                System.out.print("\n -------------------------------------------------\n");
                                System.out.print(" |                STAMPA INFO STUDENTI           |\n");
                                System.out.print(" -------------------------------------------------\n");

                                for(int j = 0; j != students[0].counter; j++) {
                                    students[j].printStudents(j);
                                }

                                if(students[0].counter < 1)
                                    System.out.print("\n Non ci sono ancora studenti");

                                System.out.print("\n\n ---------------------------------------------------\n");
                                System.out.print(" |     Premi invio per tonare alle funzioni...     |\n");
                                System.out.print(" ---------------------------------------------------\n");

                                cont = scanner.nextLine();
                                break;

                            case 2:
                                Menu.cls();
                                Menu.title();

                                System.out.print("\n -------------------------------------------------\n");
                                System.out.print(" |       STAMPA STUDENTE MIGLIORE/PEGGIORE       |\n");
                                System.out.print(" -------------------------------------------------\n");

                                for(short j = 0; j != students[0].counter; j++) {
                                    if(students[j].vote > betterVote) {
                                        betterVote = students[j].vote;
                                        betterPosition = j;
                                    }

                                    if(students[j].vote < worseVote) {
                                        worseVote = students[j].vote;
                                        worsePosition = j;
                                    }
                                }

                                System.out.println("\n Studente migliore: " + students[betterPosition].name + " " + students[betterPosition].surname);
                                System.out.println(" Studente peggiore: " + students[worsePosition].name + " " + students[worsePosition].surname);

                                System.out.print("\n\n ---------------------------------------------------\n");
                                System.out.print(" |     Premi invio per tonare alle funzioni...     |\n");
                                System.out.print(" ---------------------------------------------------\n");

                                cont = scanner.nextLine();
                                break;

                            case 3:
                                Menu.cls();
                                Menu.title();

                                System.out.print("\n -------------------------------------------------\n");
                                System.out.print(" |                 STAMPA MEDIA VOTI             |\n");
                                System.out.print(" -------------------------------------------------\n\n");

                                for(int j = 0; j != students[0].counter; j++) {
                                    tot += students[j].vote;
                                }

                                System.out.print(" Media voti: " + (tot / (students[0].counter)));

                                System.out.print("\n\n ---------------------------------------------------\n");
                                System.out.print(" |     Premi invio per tonare alle funzioni...     |\n");
                                System.out.print(" ---------------------------------------------------\n");

                                cont = scanner.nextLine();
                                break;

                            case 4:
                                Menu.cls();
                                Menu.title();

                                System.out.print("\n -------------------------------------------------\n");
                                System.out.print(" |     STAMPA STUDENTI CHE DEVONO RECUPERARE     |\n");
                                System.out.print(" -------------------------------------------------\n\n");

                                for(int j = 0; students[j].counter != j; j++) {
                                    if(students[j].vote < 6) {
                                        students[j].printStudents(j);
                                        verify = true;
                                    }
                                }

                                if(students[0].counter < 1)
                                    System.out.print(" Non ci sono ancora studenti");

                                if(verify = false)
                                    System.out.print("Non ci sono studenti che devono recuperare");

                                System.out.print("\n\n ---------------------------------------------------\n");
                                System.out.print(" |     Premi invio per tonare alle funzioni...     |\n");
                                System.out.print(" ---------------------------------------------------\n");

                                cont = scanner.nextLine();
                                break;

                        }
                    } while(mode > 0 && mode < 5);
                    break;

                // ----------------------------------------------------------------------------
                case 0:
                    exit = true;
                    System.out.print("\nUscendo...");
                    break;
            }
        } while(exit != true);
    }
}




     */


/*
MENU DI ZECCHINI


package com.company;
import java.util.Scanner;



    public class Menu {

        // METODO PER PULIRE, NON FUNZIONANTE SU GDB ONLINE (TROVATO SU INTERNET) ------------------------------------------------------------------------
        public static void cls()
        {
            try
            {
                new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
            } catch(Exception E)
            {
                System.out.println(E);
            }
        }

        // COLLEGAMENTO AL TITOLO -----------------------------------------------------------------------------------
        public static void mainMenu() {

            Scanner scanner = new Scanner(System.in);
            byte mode;
            String cont;

            title();

            System.out.print("\n                      ---------------------\n");
            System.out.print("                      | PREMI UN INVIO... |\n");
            System.out.print("                      ---------------------\n");

            cont = scanner.nextLine();
        }

        // TITOLO ---------------------------------------------------------------------------------------------------------------------
        public static void title() {

            Scanner scanner = new Scanner(System.in);

            System.out.print("\n ███████╗████████╗██╗   ██╗██████╗ ███████╗███╗   ██╗████████╗██╗\n");
            System.out.print(" ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██╔════╝████╗  ██║╚══██╔══╝██║\n");
            System.out.print(" ███████╗   ██║   ██║   ██║██║  ██║█████╗  ██╔██╗ ██║   ██║   ██║\n");
            System.out.print(" ╚════██║   ██║   ██║   ██║██║  ██║██╔══╝  ██║╚██╗██║   ██║   ██║\n");
            System.out.print(" ███████║   ██║   ╚██████╔╝██████╔╝███████╗██║ ╚████║   ██║   ██║\n");
            System.out.print(" ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   ╚═╝\n");
        }

        // ERRORE MODALITA' ---------------------------------------------------------------------------------------------------------------------
        public static void menuError() {

            Scanner scanner = new Scanner(System.in);

            System.out.print("\n\n ------------------------------------------------\n");
            System.out.print(" |                    ERRORE                    |\n");
            System.out.print(" |----------------------------------------------|\n");
            System.out.print(" |                                              |\n");
            System.out.print(" | Errore, la modalita' inserita e' inesistente |\n");
            System.out.print(" | Premi invio per continuare...                |\n");
            System.out.print(" ------------------------------------------------\n");

            String cont = scanner.nextLine();
        }

        // MENU' GENERALE -------------------------------------------------------------------------------------------------------
        public static byte generalMenu() {

            Scanner scanner = new Scanner(System.in);

            cls();
            title();
            System.out.print("\n --------------------------\n");
            System.out.print(" |     MENU' GENERALE     |\n");
            System.out.print(" |------------------------|\n");
            System.out.print(" | 1. Crea Nuovo Studente |\n");
            System.out.print(" | 2. Funzioni            |\n");
            System.out.print(" |                        |\n");
            System.out.print(" | 0. Esci                |\n");
            System.out.print(" --------------------------\n\n");

            System.out.print(" Modalita': ");
            byte mode = scanner.nextByte();
            scanner.nextLine();

            return mode;
        }

        // MENU' FUNZIONI -------------------------------------------------------------------------------------------------------
        public static byte functionsMenu() {

            Scanner scanner = new Scanner(System.in);

            cls();
            title();
            System.out.print("\n -------------------------------------------------\n");
            System.out.print(" |                 MENU' FUNZIONI                |\n");
            System.out.print(" |-----------------------------------------------|\n");
            System.out.print(" | 1. Stampa Info Studenti                       |\n");
            System.out.print(" | 2. Stampa Studente migliore/peggiore          |\n");
            System.out.print(" | 3. Stampa Media Voti                          |\n");
            System.out.print(" | 4. Stampa Studenti che devono recuperare      |\n");
            System.out.print(" |                                               |\n");
            System.out.print(" | 0. Torna indietro                             |\n");
            System.out.print(" -------------------------------------------------\n\n");

            System.out.print(" Modalita': ");
            byte mode = scanner.nextByte();
            scanner.nextLine();

            return mode;
        }
    }


 */



