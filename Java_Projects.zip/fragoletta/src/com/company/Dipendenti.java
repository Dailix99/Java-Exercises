package com.company;

public class Dipendenti
{
    private String cognome;
    private String nome;
    private String indirizzo;
    private int matricola;
    private double stipendio;

    public Dipendenti(String cognom, String nom, String indirizz,int matricol , double stipend) {
        this.cognome = cognom;
        this.nome = nom;
        this.indirizzo = indirizz;
        this.matricola=matricol;
        this.stipendio=stipend;
    }

    public String getCognome() {
        return cognome;
    }

    public String getNome() {
        return nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public int getMatricola() {
        return matricola;
    }

    public double getStipendio() {
        return stipendio;
    }



    public void setCognome(String c) {
         cognome = c;
    }

    public void setNome(String n) {
        nome = n;
    }

    public void setIndirizzo(String i) {
        indirizzo = i;
    }

    public  void setMatricola(int m){
        matricola=m;
    }

    public  void setStipendio(double s){
        stipendio=s;
    }

    public String toString()
    {
        return " COGNOME:" + this.cognome + " | NOME:" + this.nome + " | INDIRIZZO:" + this.indirizzo + " | MATRICOLA:" + this.matricola + " | STIPENDIO:" + this.stipendio;
    }



    public void compare(double st1 , double st2) {
        if(st1==st2)
        {
            System.out.println("i 2 stipendi sono uguali");
        }

        else if(st1>st2)
        {
            System.out.println("lo stipendio del primo dipendente e' piu' alto");
        }
        else{
            System.out.println("lo stipendio del secondo  dipendente e' piu' alto");
        }


    }
}


/*
package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {

        Scanner a = new Scanner(System.in);

        System.out.println("inserisci il cognome del 1 dipendente:");
        String cognom = a.nextLine();
        System.out.println("inserisci il nome del 1 dipendente:");
        String nom = a.nextLine();
        System.out.println("inserisci l indirizzo del 1 dipendente:");
        String indirizz = a.nextLine();
        System.out.println("inserisci la matricola del 1 dipendente");
        int matricol = a.nextInt();
        System.out.println("inserisci lo stipendio del 1 dipendente");
        double stipend = a.nextDouble();

        Dipendenti d1 = new Dipendenti(cognom, nom, indirizz , matricol, stipend);

        System.out.println();

        a.nextLine();

        System.out.println("inserisci il cognome del 2 dipendente:");
        String cognom2 = a.nextLine();
        System.out.println("inserisci il nome del 2 dipendente:");
        String nom2 = a.nextLine();
        System.out.println("inserisci l indirizzo del 2 dipendente:");
        String indirizz2 = a.nextLine();
        System.out.println("inserisci la matricola del 2 dipendente");
        int matricol2 = a.nextInt();
        System.out.println("inserisci lo stipendio del 2 dipendente");
        double stipend2 = a.nextDouble();

        Dipendenti d2 = new Dipendenti(cognom2, nom2, indirizz2 , matricol2, stipend2);

        System.out.println();



        System.out.println("il 1 dipendente HA:  "+d1.toString());
        System.out.println("il 2 dipendente ha:  "+d2.toString());

         d1.compare(stipend , stipend2);



    }
}
 */
