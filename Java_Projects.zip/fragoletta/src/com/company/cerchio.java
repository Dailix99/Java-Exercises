package com.company;

public class cerchio {
    double raggio;

    public cerchio(double r) {
        this.raggio=r;
    }
    public void calcolaCirconferenza() {
        double circonferenza= 2* Math.PI * raggio;
        System.out.println("la circonferenza del cerchio e': "+ circonferenza);
    }

    public void calcolaArea() {
        double area=Math.PI * raggio*raggio;
        System.out.println("l'area del cerchio e': "+ area);
    }





}



/*
import java.util.Scanner;
import java.lang.Math;

public class Main {

    public static void main(String[] args) {

                Scanner in = new Scanner(System.in);

                cerchio c = new cerchio(3.5);
                cilindro i=new cilindro(2, 13);

                c.calcolaCirconferenza();
                c.calcolaArea();

                i.calcolaVolume();
                i.calcolaSuperficieTotale();
            }
        }
 */