package com.company;

import java.util.Vector;

public class Poligono {
    int cont;

    Vector<Punto> v=new Vector<>();

    public void aggiungi(Punto p)
    {
    v.addElement(p);
    System.out.println("operazione effettuata con successo");
    }

    public void rimuovi(int i)
    {
        v.removeElementAt(i);
        System.out.println("operazione effettuata con successo");
    }

    public void modifica(int i,int x,int y)
    {
        v.set(i,new Punto(x,y));
        System.out.println("operazione effettuata con successo");
    }

    public void stampa(){
        cont=1;
        for(int i=0; i<v.size();i++) {
            System.out.println("le coordinate del "+cont+" punto sono: " + v.elementAt(i).toString());
            cont++;
        }
    }


}
