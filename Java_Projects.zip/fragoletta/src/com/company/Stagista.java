package com.company;

public class Stagista extends persona {
    int numeropresenze;
    int numeroidentificativo;

    public Stagista (String cogn, String n, String codf, String cit,int np,int numiden)
    {
        super(cogn,n,codf,cit);
        this.numeropresenze = np;
        this.numeroidentificativo= numiden;
    }

    public int getNumeropresenze ()
    {
        return numeropresenze;
    }


    public int getNumeroidentificativo ()
    {
        return numeroidentificativo;
    }


    public void setNumeropresenze (int nm)
    {
        numeropresenze = nm;
    }

    public void setNumeroIdentificativo (int numiden)
    {
        numeroidentificativo = numiden;
    }



    public String stampa_stagista()
    {
        return super.stampa_persona() + " | NUMERO PRESENZE:" + numeropresenze + " | NUMERO IDENTIFICATIVO:" + numeroidentificativo;
    }
}



