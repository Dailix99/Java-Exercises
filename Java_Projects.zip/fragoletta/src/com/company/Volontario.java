package com.company;

public class Volontario extends Personale {
    public String codice_fiscale;
    public double pagafissa;

    public Volontario(String n, String i, String cf, double p) {
        super(n,i);
        this.codice_fiscale=cf;
        this.pagafissa=p;
    }


    public String toString() {
        return "Volontario[" +
                "nome='" + nome + '\'' +
                ", indirizzo='" + indirizzo + '\'' +
                ", codice_fiscale='" + codice_fiscale + '\'' +
                ']';
    }

    public double paga(){
        return pagafissa;
    }


}

