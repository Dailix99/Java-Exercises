package com.company;

public class Appartamento extends Abitazione{
    int piano;
    int num_terrazzi;
    boolean raggiungibile;

    public Appartamento(int ns,double s, String i, String c,int a,int nt,boolean r) {
        super(ns,s,i,c);
        this.piano=a;
        this.num_terrazzi=nt;
        this.raggiungibile=r;
    }


    public boolean raggiungibile(String r){
        if(r.equals("si")){
            return true;

        }
        else if(r.equals("no")){
            return false;

        }
        return false;
    }

    public String stampa_appartamento(){
        return " appartamento: " + super.stampa_abitazione() + ", piani=" + piano + ", numero terrazzi=" + num_terrazzi +  ", raggiungibile tramite ascensore=" + raggiungibile ;
    }



}
