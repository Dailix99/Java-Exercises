package com.company;

public class Scultura extends OperaArte{

private double altezza;
private double larghezza;
private double profondita;

public Scultura(String t,String a,double al,double l,double p){
    super(t,a);
    altezza=al;
    larghezza=l;
    profondita=p;
}


    public double printingombro(){
        return altezza*larghezza*profondita;
    }


    public String toString() {
        return "Scultura {" +
                "titolo='" + titolo + '\'' +
                ", artista='" + artista + '\'' +
                ", altezza=" + altezza +
                ", larghezza=" + larghezza +
                ", profondita=" + profondita +
                '}';
    }
}










