package com.company;

public class DistributoreBenzina {

    private double deposito;
    private double euroPerLitro;

    public DistributoreBenzina(double unPrezzoPerLitro) {  //COSTRUTTORE PARAMETRICO
        this.euroPerLitro = unPrezzoPerLitro ;
        this.deposito=0; //permette di richiamare una determinata istanza  di una classe
    }

    public DistributoreBenzina(){  //costruttore di default
        this.deposito=30;
        this.euroPerLitro=1.60;
    }

    public DistributoreBenzina(DistributoreBenzina p){  //costruttore di copia
        this.deposito=p.deposito;
        this.euroPerLitro=p.euroPerLitro;
    }

    public String visualizzadatidistribuore()
    {
        return " quantitativo di benzina disponibile: " + this.deposito + " | Prezzo: " + this.euroPerLitro + " euro/litro" ;
    }


    public void stampa()  //2 modo per stampare
    {
        System.out.println(" quantitativo di benzina disponibile: " + this.deposito + " | Prezzo: " + this.euroPerLitro + " euro/litro" );
    }



    public void rifornisci(double unaQuantita)
    {
        deposito = deposito + unaQuantita;
    }




    public void aggiorna(double unPrezzoPerLitro)
    {
        euroPerLitro=unPrezzoPerLitro;
    }

    public double spesatotale()
    {
        double spesa=euroPerLitro*deposito;
        return spesa;
    }


    public void compare ( DistributoreBenzina p)
    {
        if(this.deposito==p.deposito){
            System.out.println("i 2 depositi sono uguali");
        }
        else{
            System.out.println("i 2 depositi sono diversi");
        }
    }






}



/*

package com.company;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        int c;



        DistributoreBenzina d = new DistributoreBenzina(1.50);
        Scanner input = new Scanner(System.in);

        do {


            System.out.println("selezionare la  modalita' desiderata: 0 per uscire ,1 per stampare le caratteristiche , 2 per rifornire il distributore , 3 per aggiornare il prezzo del carburante");
            do {

                c = input.nextInt();
                if (c < 0 || c > 3) {
                    System.out.println("    reinserisci  ");
                }
            } while (c < 0 || c > 3);

            System.out.println();

            switch (c) {

                case 1:
                    System.out.println("il distributore ha queste caratteristiche :  \n" + d.visualizzadatidistribuore());
                    break;

                case 2:
                    System.out.println("aumenta la quantità del deposito di :");
                    d.rifornisci(input.nextDouble());
                    break;


                case 3:
                    System.out.println("aggiorna il prezzo del carburante");
                    d.aggiorna(input.nextDouble());
                    break;
            //default: System.out.println("Hai inserito ne' 1 ne' 2");
            }

            System.out.println();


        } while (c!=0);


    }
}
 */