package com.company;

public class Persona {

    private String eta;
    private String nome;
    private String sesso;
    private String professione;



    public String getEta ()
    {
        return eta;
    }

    public String getNome ()
    {
        return nome;
    }

    public String getSesso ()
    {
        return sesso;
    }
    public String getProfessione ()
    {
        return professione;
    }



    public void setEta (String m)
    {
        eta = m;
    }
    public void setNome (String n)
    {
        nome = n;
    }
    public void setSesso (String c)
    {
        sesso = c;
    }

    public void setProfessione (String c)
    {
        professione = c;
    }


    public Persona (String n, String c, String f, String u)
    {
        eta = n;
        nome = c;
        sesso = f;
        professione=u;
    }

    public String ChiSei()
    {
        return "sono una persona di | ETA':" + eta + " | NOME:" + nome + " | SESSO:" + sesso + " | PROFESSIONE:" + professione;
    }


/*
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {


        Scanner a=new Scanner(System.in);

        System.out.println("inserisci l'eta' della persona:");
        String et=a.nextLine();
        System.out.println("inserisci il nome della persona:");
        String nom=a.nextLine();
        System.out.println("inserisci il sesso della persona:");
        String sess=a.nextLine();
        System.out.println("inserisci la professione della persona:");
        String profession=a.nextLine();



        Persona Persona=new Persona(et,nom,sess,profession);

        System.out.println();
        System.out.println(Persona.ChiSei());


    }


 */

}


