package com.company;

public class complessi {

    int parte_reale, parte_immaginaria;


    public complessi(int r, int i) {
        this.parte_reale = r;
        this.parte_immaginaria = i;
    }

    public int getPartereale() {
        return parte_reale;
    }

    public void setPartereale(int r) {
        this.parte_reale = r;
    }

    public int getParteimmaginaria() {
        return parte_immaginaria;
    }

    public void setParteimmaginaria(int i) {
        this.parte_immaginaria = i;
    }


    public void modifica(String d,int m) {
        if(d.equals("r")){
          this.parte_reale=m;
        }
        else if(d.equals("i")) {
            this.parte_immaginaria=m;
        }

    }

    public void somma(complessi c) {
        int sommareale=this.parte_reale+c.getPartereale();
        int sommaimmaginaria=this.parte_immaginaria+c.getParteimmaginaria();
        System.out.println(sommareale+"+"+sommaimmaginaria+"i\n");

    }

    public void differenza(complessi d) {
        int sommareale=this.parte_reale-d.getPartereale();
        int sommaimmaginaria=this.parte_immaginaria-d.getParteimmaginaria();
        System.out.println(sommareale+"+("+sommaimmaginaria+")i\n");

    }

    public void prodotto(complessi f) {
        int sommareale = this.parte_reale * f.getPartereale();
        int sommaimmaginaria = this.parte_immaginaria * f.getParteimmaginaria();
        int somma2 = this.parte_reale * f.getParteimmaginaria();
        int somma3 = this.parte_immaginaria * f.getPartereale();
        System.out.print("["+sommareale +"-("+ sommaimmaginaria + ")]"+"+");
        System.out.println("("+somma2 +"+"+ somma3 + ")i\n");
        System.out.println(" il risultato finale e':\n");
        int somf1=sommareale-sommaimmaginaria;
        int somf2=somma2+somma3;
        System.out.println(somf1 +"+ ("+ somf2 +")i\n");


    }

    public String stampanum_complesso()
    {
        return this.parte_reale+"+"+this.parte_immaginaria +"i";
    }


}



/*


package com.company;

import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {

        int scelta,n,nm;
        String sce;


        Scanner a = new Scanner(System.in);
        System.out.println("inserisci la parte reale del 1 numero complesso");
        int reale= a.nextInt();
        System.out.println("inserisci la parte immaginaria del 1 numero complesso");
        int immaginaria = a.nextInt();

        complessi c1 = new complessi(reale,immaginaria);

        System.out.println();

        a.nextLine();

        System.out.println("inserisci la parte reale del 2 numero complesso");
        int reale2= a.nextInt();
        System.out.println("inserisci la parte immaginaria del 2 numero complesso ");
        int immaginaria2 = a.nextInt();

        complessi c2 = new complessi(reale2,immaginaria2);

        System.out.println();
        do {
            System.out.println("inserisci \n 1 per modificare un numero complesso  \n 2 per stampare i 2 numeri complessi \n 3  per fare la differenza dei numeri complessi\n 4  per fare il prodotto dei numeri complessi\n 5 per sommare i  2 numeri complessi\n 0 per uscire");
            scelta=a.nextInt();
            switch (scelta) {


                case 1:

                    System.out.println("quale numero complesso vuoi modificare? inserisci 1 per il primo / 2 per il secondo");
                    n=a.nextInt();
                    if(n==1)
                    {
                        a.nextLine();
                        System.out.println("vuoi modificare la parte reale o la parte immaginaria? inserisci 'r' per la parte reale / 'i' per la parte immaginaria");
                        sce=a.nextLine();
                        System.out.println("inserisci il nuovo numero da sostituire");
                        nm=a.nextInt();
                        c1.modifica(sce,nm);
                    }
                    else if(n==2) {
                        a.nextLine();
                        System.out.println("vuoi modificare la parte reale o la parte immaginaria? inserisci 'r' per la parte reale / 'i' per la parte immaginaria");
                        sce = a.nextLine();
                        System.out.println("inserisci il nuovo numero da sostituire");
                        nm = a.nextInt();
                        c2.modifica(sce, nm);
                    }


                    break;

                case 2:

                    System.out.println("il 1 numero complesso e':  "+c1.stampanum_complesso());
                    System.out.println("il 2 numero complesso e':  "+c2.stampanum_complesso());

                    break;

                case 3:
                    c1.differenza(c2);

                    break;


                case 4:
                    c1.prodotto(c2);
                    break;

                case 5:
                    c1.somma(c2);
                    break;



            }

        } while (scelta != 0) ;

    }
}




 */