package com.company;

public class Dipendent extends Personale{
    public String codice_fiscale;
    public double basediretr;


    public Dipendent(String n,String i,String cf,double bdr) {
        super(n,i);
        this.codice_fiscale=cf;
        this.basediretr=bdr;

    }


    public String toString() {
        return "Dipendent[" +
                "nome='" + nome + '\'' +
                ", indirizzo='" + indirizzo + '\'' +
                ", codice_fiscale='" + codice_fiscale + '\'' +
                ", basediretr=" + basediretr +
                ']';
    }

    public double paga(){
        return basediretr;
    }



}
