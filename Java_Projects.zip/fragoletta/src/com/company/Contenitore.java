package com.company;

public abstract class Contenitore<pulic> implements CMP {
    public String codice;
    public String nomeliquido;
    public double quantita;




    public Contenitore(String c,String n, double q) {
        this.codice=c;
        this.nomeliquido = n;
        this.quantita = q;
    }

    public String getCodice() {
        return codice;
    }

    public String getNomeLiquido() {
        return nomeliquido;
    }

    public double getQuantita() {
        return quantita;
    }

    //metodo astratto
    public abstract String toString();

    //metodo concreto
    public void confronta(Contenitore c) {
        if (this.quantita == c.getQuantita()) {
            System.out.println("i contenitori hanno medesima quantita'");
        } else {

           double differenza;
            differenza = this.quantita - c.getQuantita();
            if(differenza <=0){
                System.out.println("impossibile fare la differenza dato che la quantita' del primo contenitore e' inferiore alla quantita' del secondo");
            }
            else {
                System.out.println("il  rapporto  tra i due contenitori e' " + differenza);
            }

        }

    }

}




/*



package com.company;

import java.util.*;

public class Main {
        public static void main(String[] args) {

                int scelta,scelta2,contq=1,conts=1;
                int j=0,i,y,dim,cont_oggetti=0;
                double quantita;
                String codice,nome,con1,con2;


                Scanner in = new Scanner(System.in);

                System.out.println("\ninserisci il numero di contenitori massimo desiderato: ");
                dim=in.nextInt();
                Contenitore c[]=new Contenitore[dim];

                Utils u=new Utils();


                in.nextLine();

                do {
                        System.out.println("\ninserisci: \n 1 per aggiungere una un nuovo contenitore \n 2 per stampare le caratteristiche di tutti i contenitori \n 3 per confrontare 2 contenitori \n 4 per filtrare i contenitori  \n 0 per uscire");

                        scelta = in.nextInt();
                        in.nextLine();

                        switch (scelta) {



                                case 1:


                                        System.out.println("\ninserire... \n 1 per aggiungere una lattina  \n 2 per aggiungere un bidone");
                                        scelta2 = in.nextInt();

                                        in.nextLine();


                                        switch (scelta2) {

                                                case 1:

                                                        System.out.println("\ninserisci il codice univoco  della " + contq + " lattina ");
                                                        codice = in.nextLine();
                                                        System.out.println("\ninserisci il nome del liquido della " + contq + " lattina ");
                                                        nome = in.nextLine();
                                                        System.out.println("\ninserisci la quantita della " + contq + " lattina ");
                                                        quantita = in.nextDouble();

                                                        try {
                                                                c[cont_oggetti] =new Lattine(codice,nome,quantita);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }

                                                        contq++;

                                                        break;



                                                case 2:

                                                        System.out.println("\ninserisci il codice univoco  del " + conts + " bidone ");
                                                        codice = in.nextLine();
                                                        System.out.println("\ninserisci il nome del liquido del" + conts + " bidone ");
                                                        nome = in.nextLine();
                                                        System.out.println("\ninserisci la quantita del " + conts + " bidone ");
                                                        quantita = in.nextDouble();

                                                        try {
                                                                c[cont_oggetti] =new Bidoni(codice,nome,quantita);
                                                                cont_oggetti++;
                                                        }
                                                        catch (ArrayIndexOutOfBoundsException e){
                                                                System.out.println("\n ERRORE:dimensione massima dell'array superata ,pertanto non è possibile aggiungere un nuovo oggetto");
                                                        }
                                                        conts++;

                                                        break;



                                        }//chiusura  del menu interno del 1 case del menu principale
                                        break;  //chiusura  del 1 case del menu principale


                                case 2:
                                        int conta1=1;

                                        for(i=0; i<c.length; i++) {
                                                System.out.println(conta1+" contenitore,ovvero--> "+c[i].toString());
                                                conta1++;
                                        }

                                        break;



                                case 3:
                                        System.out.println("\ninserisci il codice univoco del 1 contenitore da confrontare \n");
                                        con1=in.nextLine();

                                        for ( i = 0;  i< c.length; i++) {

                                                if (c[i].getCodice().equals(con1)) {
                                                        j=i; //salvo posizione
                                                        System.out.println("\n 1 contenitore trovato!ovvero-->:"+c[i].toString()+("\n"));
                                                }
                                        }

                                        System.out.println("\ninserisci il codice univoco del 2 contenitore da confrontare \n");
                                        con2=in.nextLine();

                                        for (y = 0; y < c.length; y++) {

                                                if (c[y].getCodice().equals(con2)) {
                                                        System.out.println("\n 2 contenitore trovato! ovvero-->:"+c[y].toString()+("\n"));
                                                        c[j].confronta(c[y]); //richiamo il metodo confronta
                                                }
                                        }

                                        break;

                                case 4:
                                        System.out.println("\ninserisci il codice univoco  del contenitore campione");
                                        codice = in.nextLine();
                                        System.out.println("\ninserisci il nome del liquido del contenitore campione ");
                                        nome = in.nextLine();
                                        System.out.println("\ninserisci la quantita del contenitore campione ");
                                        quantita = in.nextDouble();
                                        Contenitore cn=new Lattine(codice,nome,quantita);
                                        c=u.filtra(c,cn);    //sostituzione dell'array di oggetti antecente con l'array di contenitori filtrato

                                        break;


                        }  //chiudo switch principale

                } while (scelta != 0);  //ripeto fino a quando scelta e' diverso da 0


        }
}







 */