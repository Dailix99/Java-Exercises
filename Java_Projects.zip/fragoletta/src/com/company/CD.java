package com.company;

public class CD {

    private String titolo;
    private String autore;
    private int numero_brani;
    private double durata;

    public String getTitolo() {
        return titolo;
    }

    public String getAutore() {
        return autore;
    }

    public int getNumero_brani() {
        return numero_brani;
    }

    public double getDurata() {
        return durata;
    }

    public void setTitolo(String m) {
        titolo = m;
    }

    public void setAutore(String n) {
        autore = n;
    }

    public void setNumero_brani(int c) {
        numero_brani = c;
    }

    public void setDurata(double c) {
        durata = c;
    }


    public CD(String a, String u, int f, double e) {
        this.titolo = a;
        this.autore = u;
        this.numero_brani = f;
        this.durata = e;
    }

    public String toString() {
        return " TITOLO:" + this.titolo + " | AUTORE:" + this.autore + " | NUMERO BRANI:" + this.numero_brani + " | DURATA:" + this.durata;
    }


    public String compareDurata(double dura, double durat) {
        if (dura == durat) {
            return "la durata e' la stessa";
        } else {
            return "la durata e' diversa";
        }

    }

}


    /*

    import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {

        Scanner a = new Scanner(System.in);                               metti questo

        System.out.println("inserisci il titolo del primo CD:");
        String tit = a.nextLine();
        System.out.println("inserisci l'autore del  primo CD:");
        String aut = a.nextLine();
        System.out.println("inserisci il numero brani del primo CD:");
        int numbr = a.nextInt();
        System.out.println("inserisci la durata del primo CD:");         metti questo
        double dura = a.nextDouble();                metti questo

        CD cd1 = new CD(tit, aut, numbr, dura);                          metti questo

        System.out.println();
        a.nextLine();

        System.out.println("inserisci il titolo del secondo CD:");
        String tito=a.nextLine();
        System.out.println("inserisci l'autore del secondo CD:");
        String auto=a.nextLine();
        System.out.println("inserisci il numero brani del secondo CD:");
        int numbra=a.nextInt();
        System.out.println("inserisci la durata del  secondo CD:");       metti questo
        double durat=a.nextDouble();                                      metti questo

        CD cd2=new CD(tito,auto,numbra,durat);                            metti questo


        System.out.println();



        System.out.println("il 1 CD HA:  "+cd1.toString());
        System.out.println("il 2 CD HA:  "+cd2.toString());

        System.out.println(cd1.compareDurata(dura,durat));                 metti questo



    }
}


     */


