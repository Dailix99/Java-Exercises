package com.company;

public class Villa extends Abitazione{
    int num_piani;
    double superficie_giardino;
    boolean piscina;

    public Villa(int ns,double s, String i, String c,int nm,double sg,boolean p) {
        super(ns,s,i,c);
        this.num_piani=nm;
        this.superficie_giardino=sg;
        this.piscina=p;
    }


    public boolean piscina(String p){
        if(p.equals("si")){
            return true;
        }
        else if(p.equals("no")){
            return false;
        }
    return false;
    }


    public String stampa_villa(){
        return " villa: " + super.stampa_abitazione() + ", numero piani=" + num_piani + ", superficie del giardino=" + superficie_giardino +  ", piscina=" + piscina ;
    }


}
