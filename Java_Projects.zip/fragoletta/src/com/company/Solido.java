package com.company;

public abstract class Solido {

    public double pesospecifico;
    public double volume;

    public Solido(double ps,double v){
        pesospecifico=ps;
        volume=v;
    }

    //metodo concreto che calcolera' il peso di tutti i solidi
    public double peso(){
        return volume*pesospecifico;
    }

    //dichiarazione dei metodi astratti
    public abstract String getDescrizione();
    public abstract double superficie();
    public abstract double volume();


}


/*

public class Main {

        public static void main(String[] args) {
                int cont=1;

                Solido s[] = new Solido[2];    //creo array di oggetti di tipo solido
                s[0] = new Cubo(5600, 200, 3);    //il primo oggetto sara' il cubo
                s[1] = new Sfera(8600, 120, 6.5 );   //il primo oggetto sara' la sfera


                for (int i = 0; i < 2; i++) {
                        System.out.println("il peso del "+cont+" solido e': "+s[i].peso());  //richiamo metodo calcola peso di tutti i solidi
                        cont++;
                }

                for (int i = 0; i < 2; i++) {
                        System.out.println(s[i].getDescrizione()+" e superficie "+s[i].superficie());  //richiamo metodo descrizione e superficie di tutti i solidi
                }         //il metodo calcola volume non sara' richiamato perche' per calcolare il peso e' gia' necessario il volume


        }
}
 */