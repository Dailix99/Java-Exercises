package com.company;

import java.util.Date;

public class Sito {

public String sito;
public Date time;



    public Sito(String st, Date s) {
        this.sito=st;
        this.time=s;
    }


    public String Cronologia(){
        return "https://www." + sito+ ".com   --> date: "+time;


    }

}



/*
package com.company;
import java.util.Date;
import java.util.Scanner;
import java.util.Vector;
import java.util.GregorianCalendar;
import java.lang.ArrayIndexOutOfBoundsException;
import java.util.InputMismatchException;


public class Main {
    public static void main(String[] args) {
        int scelta;

        Scanner a = new Scanner(System.in);

        Vector<Sito>s =new Vector<>();

        GregorianCalendar g=new GregorianCalendar();




        do {
            System.out.println("\ninserisci: \n1 per cercare\n2 per visualizzare la cronologia\n3 per eliminare tutta la cronologia \n4 per eliminare l'ultimo sito visitato \n0 per uscire");

/*
            try {
                scelta = a.nextInt();
            }
            catch (InputMismatchException e){
                System.out.println("\n ERRORE:inserire un intero e non una stringa");
            }
*/
/*
            scelta = a.nextInt();
                    a.nextLine();

                    switch (scelta) {


                    case 1:
                    String sito_cercato=a.nextLine();
                    Date time=g.getTime();
                    Sito st =new Sito(sito_cercato,time); //creo oggetto di tipo sito
                    s.addElement(st);                     //attribuzione dell'oggetto al vettore

                    break;

                    case 2:
                    for(int i=s.size()-1; i>=0; i--){
                    System.out.println(s.elementAt(i).Cronologia());  //richiamo metodo cronologia
                    }
                    break;

                    case 3:
                    for(int i=0; i<s.size(); i++){
        s.removeAllElements();
        System.out.println("\noperazione effetuata :)");
        }
        break;

        case 4:

        try {
        s.removeElementAt(s.size()-1);
        System.out.println("\noperazione effetuata :)");
        }
        catch (ArrayIndexOutOfBoundsException e){
        System.out.println("\n ERRORE:non ci sono oggetti nell'array,pertanto non è possibile eliminare");
        }
        break;
        }

        } while (scelta != 0);


        }
        }


        */