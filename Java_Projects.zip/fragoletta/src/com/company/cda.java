package com.company;

public class cda {

    private String titolo;
    private int durata;



    public cda(String n, int f) {
        this.titolo = n;
        this.durata = f;
    }

    public String getTitolo() {
        return this.titolo;
    }

    public int getDurata() {
        return this.durata;
    }

    public void modificatit(String titolomodificato) {
        this.titolo=titolomodificato;
    }

    public void modificadur(int duratamodificata) {
        this.durata=duratamodificata;
    }


    public int restituiscidurata(String titolo) {
        System.out.println("la durata della canzone selezionata è");
        return this.durata;
    }


}








/*


package com.company;

import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        String tit,tite,tite1,tite2,titol;
        int cont=1,durat,n=3,n2,nub=0,te,cont2=1;
        int scelta,indice=0;


        Scanner a = new Scanner(System.in);

        n2=n;

        cda c[] = new cda[n];

        do {
            System.out.println("\ninserisci \n 1 per aggiungere una canzone  \n 2 per modificare il titolo di una canzone \n 3 per modificare la durata di una canzone\n 4 per restituire la durata dato il titolo\n 5 per stampare titolo/canzone delle canzoni\n 0 per uscire\n");
            scelta=a.nextInt();
            switch (scelta) {


                case 1:
                    if (indice >= n) {
                        System.out.println("\nnumero massimo di canzoni da poter inserire superato\n");
                    }

                    else{
                        do {
                            System.out.println("inserisci il numero di brani che vuoi inserire nel sistema:");
                            nub = a.nextInt();
                            if(nub>n2){
                                System.out.println("reinserire,numero massimo di canzoni da poter inserire superato\n");
                            }
                        }while(nub>n2);

                        for (int i = indice; i < indice+nub; i++) {
                            a.nextLine();
                            System.out.println("\ninserisci il titolo della "+cont+" canzone " );
                            titol=a.nextLine();
                            System.out.println("\ninserisci il la durata della "+cont+" canzone " );
                            durat=a.nextInt();
                            cont++;
                            c[i] = new cda(titol, durat);
                            n2--;
                        }
                    }
                    indice+=nub;
                    a.nextLine();

                    break;

                case 2:
                    a.nextLine();
                    System.out.println("\ninserisci il titolo della canzone di cui vuoi modificarne il titolo\n");
                    tite=a.nextLine();

                    for (int i = 0; i < indice; i++) {

                        if (c[i].getTitolo().equals(tite)) {
                            System.out.println("\ninserisci il nuovo titolo della canzone\n");
                            tit=a.nextLine();
                            c[i].modificatit(tit);
                        }
                    }

                    break;

                case 3:
                    a.nextLine();
                    System.out.println("\ninserisci il titolo della canzone di cui vuoi modificarne la durata\n");
                    tite1=a.nextLine();

                    for (int i = 0; i < indice; i++) {

                        if (c[i].getTitolo().equals(tite1)) {
                            System.out.println("\ninserisci la nuova durata della canzone\n");
                            te=a.nextInt();
                            c[i].modificadur(te);
                        }
                    }


                    break;


                case 4:
                    a.nextLine();
                    System.out.println("\ninserisci il titolo della canzone per restituirne la relativa durata\n");
                    tite2=a.nextLine();

                    for (int i = 0; i < indice; i++) {
                        if (c[i].getTitolo().equals(tite2)) {
                            System.out.println("la canzone ha come durata " + c[i].getDurata()+ "s");
                        }
                    }

                    break;

                case 5:
                    for (int i = 0; i < indice; i++) {
                    System.out.println("la " + cont2 + " canzone ha come titolo '" + c[i].getTitolo()+"' e durata " + c[i].getDurata()+ "s");
                    cont2++;
                }

                    break;

            }

        } while (scelta != 0) ;

    }
}






 */