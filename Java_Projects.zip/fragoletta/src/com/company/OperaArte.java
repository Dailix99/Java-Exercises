package com.company;

public abstract class OperaArte {
    protected String titolo;
    protected String artista;

    public OperaArte(String t,String a){
        titolo=t;
        artista=a;
    }

    public String getTitolo() {
        return titolo;
    }

    public String getArtista() {
        return artista;
    }

    //metodo concreto
    public boolean equal(OperaArte o){
        if(this.titolo.equals(o.getTitolo()) && this.artista.equals(o.getArtista()))
                return true;
        else
                return false;
    }

    //dichiarazione del metodo astratto
    public abstract double printingombro();



}

