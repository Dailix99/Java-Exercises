package com.company;

public class Cubo extends Solido{

    public double lato;

    public Cubo(double ps,double v,double l){
     super(ps,v);
     lato=l;
    }

    public  String getDescrizione(){  //definisco concretamente il metodo (nella classe Solido e' astratto)
        return "il cubo ha come lato ["+lato+"] peso specifico ["+pesospecifico+"] volume ["+volume+"]";
    }


    public double superficie(){  //definisco concretamente il metodo (nella classe Solido e' astratto)
        return 6*lato*lato;
    }

    public double volume(){  //definisco concretamente il metodo (nella classe Solido e' astratto)
        return lato*lato*lato;
    }


}





